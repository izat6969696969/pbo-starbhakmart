import 'package:flutter/material.dart';
import 'pages/add_product_page.dart';

class ProductListPage extends StatefulWidget {
  const ProductListPage({super.key});

  @override
  _ProductListPageState createState() => _ProductListPageState();
}

class _ProductListPageState extends State<ProductListPage> {
  List<Map<String, dynamic>> products = [
    {
      "name": "Burger King Medium",
      "price": 69000,
      "imagePath": "assets/burger_king_medium2.jpg",
      "category": "Makanan"
    },
    {
      "name": "Teh Botol",
      "price": 5000,
      "imagePath": "assets/teh_botol.jpg",
      "category": "Minuman"
    },
    {
      "name": "Burger King Small",
      "price": 59000,
      "imagePath": "assets/burger_king_small.jpg",
      "category": "Makanan"
    },
    {
      "name": "fries",
      "price": 13000,
      "imagePath": "assets/burger_king_fries.jpg",
      "category": "Makanan"
    },
    {
      "name": "orange juice",
      "price": 6400,
      "imagePath": "assets/tropicana.jpg",
      "category": "Minuman"
    },
  ];

  void _deleteProduct(int index) {
    setState(() {
      products.removeAt(index);
    });
  }

  void _navigateToAddPage(BuildContext context) async {
    final result = await Navigator.pushNamed(context, '/addProduct');
    if (result != null) {
      setState(() {
        products.add(result as Map<String, dynamic>);
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Product List"),
        actions: [
          IconButton(
            icon: const Icon(Icons.account_circle),
            onPressed: () {},
          ),
        ],
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: ElevatedButton(
              onPressed: () => _navigateToAddPage(context),
              child: const Text("Add Data +"),
            ),
          ),
          Expanded(
            child: ListView.builder(
              itemCount: products.length,
              itemBuilder: (context, index) {
                final product = products[index];
                return ListTile(
                  leading: product['imagePath'] != null &&
                          product['imagePath'].isNotEmpty
                      ? Image.asset(
                          product['imagePath'],
                          width: 50,
                          height: 50,
                          fit: BoxFit.cover,
                        )
                      : Container(
                          width: 50,
                          height: 50,
                          color: Colors.grey[300],
                          child: const Icon(Icons.image_not_supported),
                        ),
                  title: Text(product['name']),
                  subtitle: Text("Rp ${product['price'].toStringAsFixed(0)}"),
                  trailing: IconButton(
                    icon: const Icon(Icons.delete, color: Colors.red),
                    onPressed: () => _deleteProduct(index),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
