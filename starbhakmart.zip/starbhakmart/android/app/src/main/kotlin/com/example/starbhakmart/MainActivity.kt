package com.example.starbhakmart

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
